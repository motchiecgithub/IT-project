from phonetics import *

# function that take a word and return the phonetic code
def phonetic_code(word):

    soundex = soundex()
    soundex_code = soundex.phonetics(word)
    print(f"Soundex: {soundex_code}")

    # Using Metaphone
    metaphone = metaphone()
    metaphone_code = metaphone.phonetics(word)
    print(f"Metaphone: {metaphone_code}")

    return soundex_code, metaphone_code


        



